[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "NoveoNative")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "NoveoNative.Pages")]
